function u = ustep(n)
    u = [zeros(10, 1); ones(n, 1)];
end

