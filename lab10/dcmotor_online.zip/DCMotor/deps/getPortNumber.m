function portNum = getPortNumber(port)
    portNum = str2double(port(4:end));
end

